Run install.exe. If this fails...

The .dll goes to your Winamp Plugins director (Usually C:/Program Files/Winamp/Plugins) 
The .bat files is dropped into your Winamp Plugins folder and ran. THIS MUST BE RAN FROM INSIDE THAT FOLDER AFTER THE DLL HAS BEEN PLACED THERE. 
Winamp.xml goes to your Mushclient/Worlds/Plugins folder. Open Mushclient and goto File->Plugins->Add->Winamp.xml 
The plugin is now installed, and ready to use. 
